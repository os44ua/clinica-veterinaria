import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../contexts/AuthContext';
import { authService } from '../services/AuthService';
import '../App.css';
import { Role } from '../interfaces/IAuthService';

const Navbar: React.FC = () => {
  const { user, roles } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await authService.signOut();
      navigate('/login');
    } catch (error) {
      console.error('Error al cerrar sesión:', error);
    }
  };

  // Determinar el panel principal según el rol
  const getPrimaryDashboard = () => {
    if (roles?.includes(Role.ADMIN)) {
      return { link: '/adminvets', text: 'Panel de Admin' };
    } else if (roles?.includes(Role.VETERINARIO)) {
      return { link: '/perfilveterinario', text: 'Panel Veterinario' };
    } else {
      return { link: '/perfilcliente', text: 'Mi Perfil' };
    }
  };

  const primaryDashboard = getPrimaryDashboard();

  return (
    <nav className="navbar">
      <div className="nav-container">
        <Link to="/" className="nav-logo">
          Clínica Veterinaria
        </Link>
        
        <ul className="nav-menu">
          <li className="nav-item">
            <Link to="/" className="nav-link">Inicio</Link>
          </li>
          
          {/* Enlaces para usuarios autenticados */}
          {user && (
            <li className="nav-item">
              <Link to={primaryDashboard.link} className="nav-link">
                {primaryDashboard.text}
              </Link>
            </li>
          )}
          
          {/* Enlaces para usuarios no autenticados */}
          {!user && (
            <>
              <li className="nav-item">
                <Link to="/login" className="nav-link">Iniciar Sesión</Link>
              </li>
              <li className="nav-item">
                <Link to="/register" className="nav-link">Registrarse</Link>
              </li>
            </>
          )}
          
          {/* Información del usuario y logout */}
          {user && (
            <>
              <li className="nav-item user-info">
                <span>Hola, {user.email}</span>
              </li>
              <li className="nav-item">
                <button onClick={handleLogout} className="logout-btn">
                  Cerrar Sesión
                </button>
              </li>
            </>
          )}
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;