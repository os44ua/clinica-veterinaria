import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../contexts/AuthContext';
import { Role } from '../interfaces/IAuthService';

const Home: React.FC = () => {
  const { user, roles } = useContext(AuthContext);

  if (user) {
    let panelLink = '';
    let panelText = '';

    if (roles?.includes(Role.ADMIN)) {
      panelLink = '/adminvets';
      panelText = 'Panel de Administración';
    } else if (roles?.includes(Role.VETERINARIO)) {
      panelLink = '/perfilveterinario';
      panelText = 'Panel del Veterinario';
    } else {
      panelLink = '/perfilcliente';
      panelText = 'Perfil del Cliente';
    }

    return (
      <div className="home-container">
        <div className="welcome-section">
          <h2>¡Bienvenido de vuelta, {user.email}!</h2>
          <p>¿Qué deseas hacer hoy en la clínica veterinaria?</p>
        </div>

        <div className="actions-section">
          <Link to={panelLink} className="btn btn-primary">
            {panelText}
          </Link>
        </div>

        <div className="user-role-info">
          <p>Rol actual: {roles?.join(', ')}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="home-container">
      <div className="hero-section">
        <h2>Bienvenido a nuestra Clínica Veterinaria</h2>
        <p>Inicia sesión o regístrate para gestionar tus citas o acceder al panel de veterinarios.</p>
      </div>

      <div className="auth-actions">
        <Link to="/login" className="btn btn-primary">
          Iniciar Sesión
        </Link>
        <Link to="/register" className="btn btn-secondary">
          Registrarse
        </Link>
      </div>

      <div className="info-section">
        <p>¡Gestiona tus mascotas y citas de manera fácil y rápida!</p>
      </div>
    </div>
  );
};

export default Home;