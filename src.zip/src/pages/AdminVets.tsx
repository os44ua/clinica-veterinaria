import { useEffect, useState } from "react";
import { getDatabase, ref, get, set } from "firebase/database";
import type { Usuario } from "../interfaces/IUsuario";

// Definimos los roles posibles
const ROLES = {
  CLIENTE: 'CLIENTE',
  VETERINARIO: 'VETERINARIO', 
  ADMIN: 'ADMIN'
} as const;

type RoleType = typeof ROLES[keyof typeof ROLES];

export default function AdminVets() {
  const [usuarios, setUsuarios] = useState<Usuario[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const db = getDatabase();

  useEffect(() => {
    cargarUsuarios();
  }, []);

  const cargarUsuarios = async () => {
    try {
      const snapshot = await get(ref(db, "users"));
      if (snapshot.exists()) {
        const data = snapshot.val();
        const listaUsuarios = Object.keys(data).map((uid) => ({
          uid,
          email: data[uid].email || "(sin email)",
          roles: data[uid].roles || {}
        }));
        setUsuarios(listaUsuarios);
      } else {
        setUsuarios([]);
      }
    } catch (err) {
      console.error("Error al cargar usuarios:", err);
      setError("Error al cargar la lista de usuarios");
    } finally {
      setLoading(false);
    }
  };

  // Función para determinar el rol actual del usuario
  const getCurrentRole = (roles: any): RoleType => {
    if (roles?.admin) return ROLES.ADMIN;
    if (roles?.veterinario) return ROLES.VETERINARIO;
    return ROLES.CLIENTE;
  };

  // Función para cambiar el rol del usuario
  const changeUserRole = async (uid: string, newRole: RoleType) => {
    try {
      // Preparamos los nuevos roles
      const newRoles = {
        admin: newRole === ROLES.ADMIN,
        veterinario: newRole === ROLES.VETERINARIO,
        cliente: true // Todos son clientes por defecto
      };

      // Actualizamos en Firebase
      await set(ref(db, `users/${uid}/roles`), newRoles);

      // Actualizamos el estado local
      setUsuarios((prev) =>
        prev.map((user) =>
          user.uid === uid
            ? { ...user, roles: newRoles }
            : user
        )
      );
    } catch (err) {
      console.error("Error al cambiar rol:", err);
      setError("No se pudo actualizar el rol del usuario");
    }
  };

  // Función para obtener el estilo del badge del rol
  const getRoleBadgeClass = (role: RoleType) => {
    switch (role) {
      case ROLES.ADMIN:
        return "role-badge admin";
      case ROLES.VETERINARIO:
        return "role-badge veterinario";
      case ROLES.CLIENTE:
        return "role-badge cliente";
      default:
        return "role-badge default";
    }
  };

  const getRoleText = (role: RoleType) => {
    switch (role) {
      case ROLES.ADMIN:
        return "Administrador";
      case ROLES.VETERINARIO:
        return "Veterinario";
      case ROLES.CLIENTE:
        return "Cliente";
      default:
        return "Desconocido";
    }
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-text">Cargando usuarios...</div>
      </div>
    );
  }

  return (
    <div className="admin-container">
      <div className="admin-header">
        <h2>Gestión de Roles de Usuarios</h2>
        <p>Administra los permisos y roles de los usuarios registrados</p>
      </div>

      {error && (
        <div className="error-message">
          <p>Error: {error}</p>
        </div>
      )}

      <div className="users-table-container">
        <table className="users-table">
          <thead>
            <tr>
              <th>Usuario</th>
              <th>Rol Actual</th>
              <th>Cambiar Rol</th>
            </tr>
          </thead>
          <tbody>
            {usuarios.map((user) => {
              const currentRole = getCurrentRole(user.roles);
              return (
                <tr key={user.uid}>
                  <td>
                    <div className="user-info">
                      <div className="user-avatar">
                        {user.email.charAt(0).toUpperCase()}
                      </div>
                      <div className="user-details">
                        <div className="user-email">{user.email}</div>
                        <div className="user-id">ID: {user.uid.substring(0, 8)}...</div>
                      </div>
                    </div>
                  </td>
                  
                  <td>
                    <span className={getRoleBadgeClass(currentRole)}>
                      {getRoleText(currentRole)}
                    </span>
                  </td>
                  
                  <td>
                    <select
                      value={currentRole}
                      onChange={(e) => changeUserRole(user.uid, e.target.value as RoleType)}
                      className="role-select"
                    >
                      <option value={ROLES.CLIENTE}>Cliente</option>
                      <option value={ROLES.VETERINARIO}>Veterinario</option>
                      <option value={ROLES.ADMIN}>Administrador</option>
                    </select>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {usuarios.length === 0 && (
        <div className="empty-state">
          <p>No hay usuarios registrados</p>
        </div>
      )}
    </div>
  );
}