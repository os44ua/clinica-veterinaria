// src/pages/PerfilCliente.tsx - Perfil del cliente simplificado sin iconos
import React, { useEffect, useState } from 'react';
import { useAppDispatch, useAuth, useCliente, useMascotas } from '../store/hooks';
import { 
  fetchClienteData, 
  updateClienteData, 
  clearClienteError,
  type ClienteData 
} from '../redux/clienteSlice';
import { 
  fetchMascotas, 
  addMascota, 
  updateMascota, 
  deleteMascota,
  clearMascotaError,
  type MascotaData 
} from '../redux/mascotaSlice';
import logger from '../services/logging';

// Componente para formulario de datos personales
const FormularioDatosPersonales: React.FC<{
  data: ClienteData | null;
  onSave: (data: ClienteData) => void;
  loading: boolean;
}> = ({ data, onSave, loading }) => {
  const [formData, setFormData] = useState<ClienteData>({
    nombre: '',
    apellidos: '',
    dni: '',
    telefono: '',
    direccion: '',
    fechaNacimiento: '',
    genero: 'otro'
  });

  useEffect(() => {
    if (data) {
      setFormData(data);
    }
  }, [data]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    logger.info('Enviando datos del formulario cliente');
    onSave(formData);
  };

  return (
    <div className="form-card">
      <h3 className="form-title">Datos Personales</h3>
      
      <form onSubmit={handleSubmit} className="client-form">
        <div className="form-grid">
          <div className="form-group">
            <label>Nombre *</label>
            <input
              type="text"
              name="nombre"
              value={formData.nombre}
              onChange={handleChange}
              required
              placeholder="Tu nombre"
              className="form-input"
            />
          </div>
          
          <div className="form-group">
            <label>Apellidos *</label>
            <input
              type="text"
              name="apellidos"
              value={formData.apellidos}
              onChange={handleChange}
              required
              placeholder="Tus apellidos"
              className="form-input"
            />
          </div>
          
          <div className="form-group">
            <label>DNI *</label>
            <input
              type="text"
              name="dni"
              value={formData.dni}
              onChange={handleChange}
              required
              pattern="[0-9]{8}[A-Za-z]"
              placeholder="12345678A"
              className="form-input"
            />
          </div>
          
          <div className="form-group">
            <label>Teléfono *</label>
            <input
              type="tel"
              name="telefono"
              value={formData.telefono}
              onChange={handleChange}
              required
              placeholder="+34 666 777 888"
              className="form-input"
            />
          </div>
          
          <div className="form-group">
            <label>Fecha de Nacimiento</label>
            <input
              type="date"
              name="fechaNacimiento"
              value={formData.fechaNacimiento}
              onChange={handleChange}
              className="form-input"
            />
          </div>
          
          <div className="form-group">
            <label>Género</label>
            <select
              name="genero"
              value={formData.genero}
              onChange={handleChange}
              className="form-input"
            >
              <option value="masculino">Masculino</option>
              <option value="femenino">Femenino</option>
              <option value="otro">Prefiero no especificar</option>
            </select>
          </div>
        </div>
        
        <div className="form-group">
          <label>Dirección</label>
          <textarea
            name="direccion"
            value={formData.direccion}
            onChange={handleChange}
            rows={3}
            placeholder="Tu dirección completa"
            className="form-textarea"
          />
        </div>
        
        <div className="form-actions">
          <button
            type="submit"
            disabled={loading}
            className="btn btn-primary"
          >
            {loading ? 'Guardando...' : 'Guardar Datos'}
          </button>
        </div>
      </form>
    </div>
  );
};

// Componente para formulario de mascota
const FormularioMascota: React.FC<{
  mascota?: MascotaData;
  onSave: (data: Omit<MascotaData, 'id'>) => void;
  onCancel: () => void;
  loading: boolean;
  clienteUid: string;
}> = ({ mascota, onSave, onCancel, loading, clienteUid }) => {
  const [formData, setFormData] = useState<Omit<MascotaData, 'id'>>({
    nombre: '',
    especie: 'perro',
    raza: '',
    edad: 0,
    peso: 0,
    color: '',
    chip: '',
    genero: 'macho',
    esterilizado: false,
    observaciones: '',
    fechaNacimiento: '',
    clienteUid
  });

  useEffect(() => {
    if (mascota) {
      const { id, ...data } = mascota;
      setFormData(data);
    }
  }, [mascota]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked :
              type === 'number' ? parseFloat(value) || 0 : value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    logger.info(`Enviando formulario mascota: ${formData.nombre}`);
    onSave(formData);
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <h3>{mascota ? 'Editar' : 'Nueva'} Mascota</h3>
        </div>
        
        <form onSubmit={handleSubmit} className="pet-form">
          <div className="form-grid">
            <div className="form-group">
              <label>Nombre *</label>
              <input
                type="text"
                name="nombre"
                value={formData.nombre}
                onChange={handleChange}
                required
                placeholder="Nombre de la mascota"
                className="form-input"
              />
            </div>
            
            <div className="form-group">
              <label>Especie *</label>
              <select
                name="especie"
                value={formData.especie}
                onChange={handleChange}
                required
                className="form-input"
              >
                <option value="perro">Perro</option>
                <option value="gato">Gato</option>
                <option value="ave">Ave</option>
                <option value="reptil">Reptil</option>
                <option value="otro">Otro</option>
              </select>
            </div>
            
            <div className="form-group">
              <label>Raza *</label>
              <input
                type="text"
                name="raza"
                value={formData.raza}
                onChange={handleChange}
                required
                placeholder="Raza de la mascota"
                className="form-input"
              />
            </div>
            
            <div className="form-group">
              <label>Edad (años) *</label>
              <input
                type="number"
                name="edad"
                value={formData.edad}
                onChange={handleChange}
                required
                min="0"
                max="30"
                className="form-input"
              />
            </div>
            
            <div className="form-group">
              <label>Peso (kg)</label>
              <input
                type="number"
                name="peso"
                value={formData.peso}
                onChange={handleChange}
                min="0"
                step="0.1"
                className="form-input"
              />
            </div>
            
            <div className="form-group">
              <label>Color</label>
              <input
                type="text"
                name="color"
                value={formData.color}
                onChange={handleChange}
                placeholder="Color del pelaje"
                className="form-input"
              />
            </div>
            
            <div className="form-group">
              <label>Chip</label>
              <input
                type="text"
                name="chip"
                value={formData.chip}
                onChange={handleChange}
                placeholder="Número de chip"
                className="form-input"
              />
            </div>
            
            <div className="form-group">
              <label>Género *</label>
              <select
                name="genero"
                value={formData.genero}
                onChange={handleChange}
                required
                className="form-input"
              >
                <option value="macho">Macho</option>
                <option value="hembra">Hembra</option>
              </select>
            </div>
            
            <div className="form-group">
              <label>Fecha de Nacimiento</label>
              <input
                type="date"
                name="fechaNacimiento"
                value={formData.fechaNacimiento}
                onChange={handleChange}
                className="form-input"
              />
            </div>
            
            <div className="form-group checkbox-group">
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  name="esterilizado"
                  checked={formData.esterilizado}
                  onChange={handleChange}
                  className="checkbox-input"
                />
                ¿Está esterilizado/a?
              </label>
            </div>
          </div>
          
          <div className="form-group">
            <label>Observaciones</label>
            <textarea
              name="observaciones"
              value={formData.observaciones}
              onChange={handleChange}
              rows={3}
              placeholder="Cualquier información adicional sobre la mascota"
              className="form-textarea"
            />
          </div>
          
          <div className="modal-actions">
            <button
              type="button"
              onClick={onCancel}
              className="btn btn-secondary"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={loading}
              className="btn btn-primary"
            >
              {loading ? 'Guardando...' : 'Guardar Mascota'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Componente principal
const PerfilCliente: React.FC = () => {
  const dispatch = useAppDispatch();
  const { firebaseUser } = useAuth();
  const { data: clienteData, loading: clienteLoading, error: clienteError, updateLoading } = useCliente();
  const { mascotas, loading: mascotasLoading, error: mascotasError, addLoading, deleteLoading } = useMascotas();
  
  const [mostrarFormularioMascota, setMostrarFormularioMascota] = useState(false);
  const [mascotaEditando, setMascotaEditando] = useState<MascotaData | undefined>();

  useEffect(() => {
    if (firebaseUser?.uid) {
      logger.info('Cargando datos del perfil cliente');
      dispatch(fetchClienteData(firebaseUser.uid));
      dispatch(fetchMascotas(firebaseUser.uid));
    }
  }, [dispatch, firebaseUser]);

  const handleSaveCliente = (data: ClienteData) => {
    if (firebaseUser?.uid) {
      dispatch(updateClienteData({ ...data, uid: firebaseUser.uid }));
    }
  };

  const handleSaveMascota = (data: Omit<MascotaData, 'id'>) => {
    if (mascotaEditando) {
      dispatch(updateMascota({ ...data, id: mascotaEditando.id! }));
    } else {
      dispatch(addMascota(data));
    }
    setMostrarFormularioMascota(false);
    setMascotaEditando(undefined);
  };

  const handleEditMascota = (mascota: MascotaData) => {
    setMascotaEditando(mascota);
    setMostrarFormularioMascota(true);
  };

  const handleDeleteMascota = (id: string) => {
    if (window.confirm('¿Estás seguro de que quieres eliminar esta mascota?')) {
      dispatch(deleteMascota({ id, clienteUid: firebaseUser!.uid }));
    }
  };

  const handleNuevaMascota = () => {
    setMascotaEditando(undefined);
    setMostrarFormularioMascota(true);
  };

  const handleCancelFormMascota = () => {
    setMostrarFormularioMascota(false);
    setMascotaEditando(undefined);
  };

  const clearErrors = () => {
    dispatch(clearClienteError());
    dispatch(clearMascotaError());
  };

  if (clienteLoading) {
    return (
      <div className="loading-container">
        <div className="loading-text">Cargando perfil del cliente...</div>
      </div>
    );
  }

  return (
    <div className="client-profile-container">
      <div className="profile-header">
        <h1>Mi Perfil de Cliente</h1>
        <p>Gestiona tu información personal y la de tus mascotas</p>
      </div>

      {/* Errores */}
      {(clienteError || mascotasError) && (
        <div className="error-container">
          <div className="error-content">
            <div className="error-icon">!</div>
            <div className="error-text">
              <h3>Ha ocurrido un error</h3>
              <p>{clienteError || mascotasError}</p>
            </div>
            <button onClick={clearErrors} className="error-close">×</button>
          </div>
        </div>
      )}

      {/* Formulario de datos personales */}
      <FormularioDatosPersonales
        data={clienteData}
        onSave={handleSaveCliente}
        loading={updateLoading}
      />

      {/* Sección de mascotas */}
      <div className="pets-section">
        <div className="pets-header">
          <h3>Mis Mascotas ({mascotas.length})</h3>
          <button
            onClick={handleNuevaMascota}
            className="btn btn-primary"
          >
            Añadir Mascota
          </button>
        </div>

        {mascotasLoading ? (
          <div className="loading-container">
            <div className="loading-text">Cargando mascotas...</div>
          </div>
        ) : mascotas.length === 0 ? (
          <div className="empty-pets">
            <div className="empty-icon">🐾</div>
            <p>Aún no has registrado ninguna mascota</p>
            <button
              onClick={handleNuevaMascota}
              className="btn btn-primary"
            >
              Registrar Primera Mascota
            </button>
          </div>
        ) : (
          <div className="pets-grid">
            {mascotas.map((mascota: MascotaData) => (
              <div key={mascota.id} className="pet-card">
                <div className="pet-header">
                  <h4>{mascota.nombre}</h4>
                  <div className="pet-actions">
                    <button
                      onClick={() => handleEditMascota(mascota)}
                      className="btn-icon edit"
                      title="Editar"
                    >
                      Editar
                    </button>
                    <button
                      onClick={() => handleDeleteMascota(mascota.id!)}
                      disabled={deleteLoading}
                      className="btn-icon delete"
                      title="Eliminar"
                    >
                      Eliminar
                    </button>
                  </div>
                </div>
                
                <div className="pet-details">
                  <p><span>Especie:</span> {mascota.especie}</p>
                  <p><span>Raza:</span> {mascota.raza}</p>
                  <p><span>Edad:</span> {mascota.edad} años</p>
                  <p><span>Género:</span> {mascota.genero}</p>
                  {mascota.peso && <p><span>Peso:</span> {mascota.peso} kg</p>}
                  {mascota.chip && <p><span>Chip:</span> {mascota.chip}</p>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modal de formulario de mascota */}
      {mostrarFormularioMascota && (
        <FormularioMascota
          mascota={mascotaEditando}
          onSave={handleSaveMascota}
          onCancel={handleCancelFormMascota}
          loading={addLoading}
          clienteUid={firebaseUser!.uid}
        />
      )}
    </div>
  );
};

export default PerfilCliente;