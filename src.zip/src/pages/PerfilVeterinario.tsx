// pages/PerfilVeterinario.tsx
import { useContext, useEffect, useState } from "react";
import { getDatabase, ref, get } from "firebase/database";
import { AuthContext } from "../contexts/AuthContext";

interface VeterinarioData {
  nombre?: string;
  apellidos?: string;
  especialidad?: string;
  telefono?: string;
  licencia?: string;
}

interface Cita {
  id: string;
  cliente: string;
  mascota: string;
  fecha: string;
  hora: string;
  estado: 'pendiente' | 'confirmada' | 'rechazada';
  motivo?: string;
}

export default function PerfilVeterinario() {
  const { user } = useContext(AuthContext);
  const [data, setData] = useState<VeterinarioData | null>(null);
  const [citas, setCitas] = useState<Cita[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    const db = getDatabase();
    
    // Cargar datos del veterinario
    const vetRef = ref(db, `veterinarios/${user.uid}`);
    get(vetRef).then((snapshot) => {
      if (snapshot.exists()) {
        setData(snapshot.val());
      } else {
        // Si no hay datos, crear perfil básico
        setData({
          nombre: "Veterinario",
          apellidos: "Apellido",
          especialidad: "Medicina General",
          telefono: "No especificado",
          licencia: "No especificado"
        });
      }
    });

    // Cargar citas pendientes (ejemplo)
    const citasRef = ref(db, `citas`);
    get(citasRef).then((snapshot) => {
      if (snapshot.exists()) {
        const citasData = snapshot.val();
        const citasVet = Object.keys(citasData)
          .filter(id => citasData[id].veterinarioId === user.uid)
          .map(id => ({ id, ...citasData[id] }));
        setCitas(citasVet);
      }
      setLoading(false);
    });

  }, [user]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-lg">🔄 Cargando panel del veterinario...</div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="bg-white rounded-lg shadow-lg">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-800">
            🩺 Panel del Veterinario
          </h2>
          <p className="text-gray-600 mt-1">
            Bienvenido, Dr. {data?.nombre} {data?.apellidos}
          </p>
        </div>

        <div className="p-6">
          {/* Información del veterinario */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="text-lg font-semibold text-blue-800 mb-3">
                📋 Información Personal
              </h3>
              <div className="space-y-2">
                <p><span className="font-medium">Nombre:</span> {data?.nombre}</p>
                <p><span className="font-medium">Apellidos:</span> {data?.apellidos}</p>
                <p><span className="font-medium">Especialidad:</span> {data?.especialidad}</p>
                <p><span className="font-medium">Teléfono:</span> {data?.telefono}</p>
                <p><span className="font-medium">Email:</span> {user?.email}</p>
              </div>
            </div>

            <div className="bg-green-50 p-4 rounded-lg">
              <h3 className="text-lg font-semibold text-green-800 mb-3">
                📊 Estadísticas
              </h3>
              <div className="space-y-2">
                <p><span className="font-medium">Citas Pendientes:</span> {citas.filter(c => c.estado === 'pendiente').length}</p>
                <p><span className="font-medium">Citas Confirmadas:</span> {citas.filter(c => c.estado === 'confirmada').length}</p>
                <p><span className="font-medium">Total Citas:</span> {citas.length}</p>
              </div>
            </div>
          </div>

          {/* Citas pendientes */}
          <div className="bg-white border rounded-lg">
            <div className="px-4 py-3 border-b bg-gray-50">
              <h3 className="text-lg font-semibold text-gray-800">
                🗓️ Citas Pendientes de Confirmación
              </h3>
            </div>
            
            {citas.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                <div className="text-4xl mb-2">📅</div>
                <p>No hay citas programadas</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-left text-sm font-medium text-gray-500">Cliente</th>
                      <th className="px-4 py-2 text-left text-sm font-medium text-gray-500">Mascota</th>
                      <th className="px-4 py-2 text-left text-sm font-medium text-gray-500">Fecha</th>
                      <th className="px-4 py-2 text-left text-sm font-medium text-gray-500">Estado</th>
                      <th className="px-4 py-2 text-left text-sm font-medium text-gray-500">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {citas.map((cita) => (
                      <tr key={cita.id}>
                        <td className="px-4 py-2">{cita.cliente}</td>
                        <td className="px-4 py-2">{cita.mascota}</td>
                        <td className="px-4 py-2">{cita.fecha} {cita.hora}</td>
                        <td className="px-4 py-2">
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            cita.estado === 'pendiente' ? 'bg-yellow-100 text-yellow-800' :
                            cita.estado === 'confirmada' ? 'bg-green-100 text-green-800' :
                            'bg-red-100 text-red-800'
                          }`}>
                            {cita.estado}
                          </span>
                        </td>
                        <td className="px-4 py-2 space-x-2">
                          {cita.estado === 'pendiente' && (
                            <>
                              <button className="text-green-600 hover:text-green-800 text-sm">
                                ✅ Confirmar
                              </button>
                              <button className="text-red-600 hover:text-red-800 text-sm">
                                ❌ Rechazar
                              </button>
                            </>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}