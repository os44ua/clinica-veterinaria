import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppDispatch, useAuth } from '../store/hooks';
import { loginUser, clearError } from '../redux/userSlice';
import { Role } from '../interfaces/IAuthService';
import logger from '../services/logging';

const Login: React.FC = () => {
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [validationError, setValidationError] = useState<string>('');
  
  const dispatch = useAppDispatch();
  const { loginLoading, error, isAuthenticated, roles } = useAuth();
  const navigate = useNavigate();

  // Redireccionar si ya está autenticado
  useEffect(() => {
    if (isAuthenticated && roles.length > 0) {
      logger.info('Usuario ya autenticado, redirigiendo');
      redirectBasedOnRole(roles);
    }
  }, [isAuthenticated, roles, navigate]);

  // Limpiar errores al desmontar componente
  useEffect(() => {
    return () => {
      dispatch(clearError());
    };
  }, [dispatch]);

  const redirectBasedOnRole = (userRoles: Role[]) => {
    if (userRoles.includes(Role.ADMIN)) {
      navigate('/adminvets');
    } else if (userRoles.includes(Role.VETERINARIO)) {
      navigate('/perfilveterinario');
    } else {
      navigate('/perfilcliente');
    }
  };

  const validateForm = (): boolean => {
    setValidationError('');
    
    if (!email.trim()) {
      setValidationError('El email es obligatorio');
      return false;
    }
    
    if (!email.includes('@')) {
      setValidationError('Introduce un email válido');
      return false;
    }
    
    if (!password.trim()) {
      setValidationError('La contraseña es obligatoria');
      return false;
    }
    
    if (password.length < 6) {
      setValidationError('La contraseña debe tener al menos 6 caracteres');
      return false;
    }
    
    return true;
  };

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    logger.info(`Intentando login para: ${email}`);
    
    try {
      const result = await dispatch(loginUser({ email, password })).unwrap();
      logger.info('Login exitoso, redirigiendo según roles');
      redirectBasedOnRole(result.roles);
    } catch (error: any) {
      logger.error(`Login falló: ${error}`);
      // El error ya se maneja en el slice
    }
  };

  const clearAllErrors = () => {
    setValidationError('');
    dispatch(clearError());
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <div className="login-header">
          <h2>Iniciar Sesión</h2>
          <p>Accede a tu cuenta de la clínica veterinaria</p>
        </div>
        
        <form className="login-form" onSubmit={handleLogin}>
          {/* Mostrar errores */}
          {(error || validationError) && (
            <div className="error-container">
              <div className="error-content">
                <div className="error-icon">!</div>
                <div className="error-text">
                  <h3>Error en el inicio de sesión</h3>
                  <p>{validationError || error}</p>
                </div>
                <button
                  type="button"
                  onClick={clearAllErrors}
                  className="error-close"
                >
                  ×
                </button>
              </div>
            </div>
          )}

          <div className="form-group">
            <label htmlFor="email">Correo electrónico</label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="tu@email.com"
              disabled={loginLoading}
              className="form-input"
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="password">Contraseña</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="••••••••"
              disabled={loginLoading}
              className="form-input"
            />
          </div>
          
          <button
            type="submit"
            disabled={loginLoading}
            className="btn btn-primary login-btn"
          >
            {loginLoading ? (
              <>
                <span className="loading-spinner">⟳</span>
                Iniciando sesión...
              </>
            ) : (
              'Iniciar Sesión'
            )}
          </button>
          
          <div className="login-footer">
            <p>
              ¿No tienes cuenta?{' '}
              <button
                type="button"
                onClick={() => navigate('/register')}
                className="link-button"
              >
                Regístrate aquí
              </button>
            </p>
          </div>
        </form>

        {/* Credenciales de prueba */}
        <div className="demo-credentials">
          <h4>Credenciales de prueba:</h4>
          <div className="credentials-list">
            <p><strong>Admin:</strong> admin@gmail.com / 123456</p>
            <p><strong>Cliente:</strong> cliente@gmail.com / 123456</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;