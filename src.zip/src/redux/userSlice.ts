// store/slices/userSlice.ts
//import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
//import { authService } from '../../services/AuthService';
//import { Role } from '../../interfaces/IAuthService';
import logger from '../services/logging';

import { createAsyncThunk, createSlice, type PayloadAction } from '@reduxjs/toolkit';
import type { Role } from '../interfaces/IAuthService';
import { authService } from '../services/AuthService';

interface UserState {
  firebaseUser: any | null;
  roles: Role[];
  isAuthenticated: boolean;
  loading: boolean;
  error: string | null;
  loginLoading: boolean;
  registerLoading: boolean;
}

const initialState: UserState = {
  firebaseUser: null,
  roles: [],
  isAuthenticated: false,
  loading: true,
  error: null,
  loginLoading: false,
  registerLoading: false,
};

// Async thunks
export const loginUser = createAsyncThunk(
  'user/login',
  async ({ email, password }: { email: string; password: string }, { rejectWithValue }) => {
    try {
      logger.info(`Attempting login for email: ${email}`);
      const userCredential = await authService.signIn(email, password);
      const roles = await authService.getUserRoles(userCredential.user);
      
      logger.info(`Login successful for user: ${email} with roles: ${roles.join(', ')}`);
      return {
        user: userCredential.user,
        roles
      };
    } catch (error: any) {
      logger.error(`Login failed for email ${email}: ${error.message}`);
      return rejectWithValue(error.message);
    }
  }
);

export const registerUser = createAsyncThunk(
  'user/register',
  async ({ email, password }: { email: string; password: string }, { rejectWithValue }) => {
    try {
      logger.info(`Attempting registration for email: ${email}`);
      const userCredential = await authService.signUp(email, password);
      
      // Establecer roles iniciales
      const userService = (await import('../services/AuthService')).userService;
      await userService.setUserRoles(userCredential.user.uid, {
        email: userCredential.user.email,
        roles: { admin: false }
      });
      
      const roles = await authService.getUserRoles(userCredential.user);
      
      logger.info(`Registration successful for user: ${email}`);
      return {
        user: userCredential.user,
        roles
      };
    } catch (error: any) {
      logger.error(`Registration failed for email ${email}: ${error.message}`);
      return rejectWithValue(error.message);
    }
  }
);

export const logoutUser = createAsyncThunk(
  'user/logout',
  async (_, { rejectWithValue }) => {
    try {
      logger.info('Attempting logout');
      await authService.signOut();
      logger.info('Logout successful');
      return true;
    } catch (error: any) {
      logger.error(`Logout failed: ${error.message}`);
      return rejectWithValue(error.message);
    }
  }
);

export const loadUserRoles = createAsyncThunk(
  'user/loadRoles',
  async (user: any, { rejectWithValue }) => {
    try {
      logger.info(`Loading roles for user: ${user.email}`);
      const roles = await authService.getUserRoles(user);
      logger.info(`Roles loaded: ${roles.join(', ')}`);
      return roles;
    } catch (error: any) {
      logger.error(`Failed to load roles: ${error.message}`);
      return rejectWithValue(error.message);
    }
  }
);

const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    setUser: (state, action: PayloadAction<{ user: any; roles: Role[] }>) => {
      state.firebaseUser = action.payload.user;
      state.roles = action.payload.roles;
      state.isAuthenticated = !!action.payload.user;
      state.loading = false;
      state.error = null;
    },
    clearUser: (state) => {
      logger.info('Clearing user state');
      state.firebaseUser = null;
      state.roles = [];
      state.isAuthenticated = false;
      state.loading = false;
      state.error = null;
    },
    setLoading: (state, action: PayloadAction<boolean>) => {
      state.loading = action.payload;
    },
    clearError: (state) => {
      state.error = null;
    },
    updateRoles: (state, action: PayloadAction<Role[]>) => {
      state.roles = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      // Login
      .addCase(loginUser.pending, (state) => {
        state.loginLoading = true;
        state.error = null;
      })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.loginLoading = false;
        state.firebaseUser = action.payload.user;
        state.roles = action.payload.roles;
        state.isAuthenticated = true;
        state.error = null;
      })
      .addCase(loginUser.rejected, (state, action) => {
        state.loginLoading = false;
        state.error = action.payload as string;
      })
      
      // Register
      .addCase(registerUser.pending, (state) => {
        state.registerLoading = true;
        state.error = null;
      })
      .addCase(registerUser.fulfilled, (state, action) => {
        state.registerLoading = false;
        state.firebaseUser = action.payload.user;
        state.roles = action.payload.roles;
        state.isAuthenticated = true;
        state.error = null;
      })
      .addCase(registerUser.rejected, (state, action) => {
        state.registerLoading = false;
        state.error = action.payload as string;
      })
      
      // Logout
      .addCase(logoutUser.pending, (state) => {
        state.loading = true;
      })
      .addCase(logoutUser.fulfilled, (state) => {
        state.firebaseUser = null;
        state.roles = [];
        state.isAuthenticated = false;
        state.loading = false;
        state.error = null;
      })
      .addCase(logoutUser.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      
      // Load roles
      .addCase(loadUserRoles.fulfilled, (state, action) => {
        state.roles = action.payload;
      })
      .addCase(loadUserRoles.rejected, (state, action) => {
        state.error = action.payload as string;
      });
  },
});

export const { setUser, clearUser, setLoading, clearError, updateRoles } = userSlice.actions;
export default userSlice.reducer;