// store/slices/clienteSlice.ts
import { createSlice, createAsyncThunk, type PayloadAction } from '@reduxjs/toolkit';
import { getDatabase, ref, get, set, update } from 'firebase/database';
import logger from '../services/logging';

export interface ClienteData {
  uid?: string;
  nombre: string;
  apellidos: string;
  dni: string;
  telefono: string;
  email?: string;
  direccion?: string;
  fechaNacimiento?: string;
  genero?: 'masculino' | 'femenino' | 'otro';
}

interface ClienteState {
  data: ClienteData | null;
  loading: boolean;
  error: string | null;
  updateLoading: boolean;
}

const initialState: ClienteState = {
  data: null,
  loading: false,
  error: null,
  updateLoading: false,
};

// Async thunks
export const fetchClienteData = createAsyncThunk(
  'cliente/fetchData',
  async (uid: string, { rejectWithValue }) => {
    try {
      logger.info(`Fetching cliente data for UID: ${uid}`);
      const db = getDatabase();
      const clienteRef = ref(db, `users/${uid}/perfil`);
      const snapshot = await get(clienteRef);
      
      if (snapshot.exists()) {
        const data = snapshot.val();
        logger.info('Cliente data fetched successfully');
        return { uid, ...data } as ClienteData;
      } else {
        logger.warn('No cliente data found, returning empty profile');
        return {
          uid,
          nombre: '',
          apellidos: '',
          dni: '',
          telefono: '',
          direccion: '',
          fechaNacimiento: '',
          genero: 'otro' as const
        } as ClienteData;
      }
    } catch (error: any) {
      logger.error(`Error fetching cliente data: ${error.message}`);
      return rejectWithValue(error.message);
    }
  }
);

export const updateClienteData = createAsyncThunk(
  'cliente/updateData',
  async (clienteData: ClienteData, { rejectWithValue }) => {
    try {
      logger.info(`Updating cliente data for UID: ${clienteData.uid}`);
      const db = getDatabase();
      const clienteRef = ref(db, `users/${clienteData.uid}/perfil`);
      
      // Excluir uid del objeto que se guarda
      const { uid, ...dataToSave } = clienteData;
      await set(clienteRef, dataToSave);
      
      logger.info('Cliente data updated successfully');
      return clienteData;
    } catch (error: any) {
      logger.error(`Error updating cliente data: ${error.message}`);
      return rejectWithValue(error.message);
    }
  }
);

export const partialUpdateCliente = createAsyncThunk(
  'cliente/partialUpdate',
  async ({ uid, updates }: { uid: string; updates: Partial<ClienteData> }, { rejectWithValue }) => {
    try {
      logger.info(`Partial update for cliente UID: ${uid}`);
      const db = getDatabase();
      const clienteRef = ref(db, `users/${uid}/perfil`);
      
      await update(clienteRef, updates);
      
      logger.info('Cliente data partially updated successfully');
      return { uid, ...updates };
    } catch (error: any) {
      logger.error(`Error in partial update: ${error.message}`);
      return rejectWithValue(error.message);
    }
  }
);

const clienteSlice = createSlice({
  name: 'cliente',
  initialState,
  reducers: {
    clearClienteData: (state) => {
      logger.info('Clearing cliente data');
      state.data = null;
      state.error = null;
    },
    clearClienteError: (state) => {
      state.error = null;
    },
    updateLocalClienteData: (state, action: PayloadAction<Partial<ClienteData>>) => {
      if (state.data) {
        state.data = { ...state.data, ...action.payload };
      }
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch cliente data
      .addCase(fetchClienteData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchClienteData.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
        state.error = null;
      })
      .addCase(fetchClienteData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      
      // Update cliente data
      .addCase(updateClienteData.pending, (state) => {
        state.updateLoading = true;
        state.error = null;
      })
      .addCase(updateClienteData.fulfilled, (state, action) => {
        state.updateLoading = false;
        state.data = action.payload;
        state.error = null;
      })
      .addCase(updateClienteData.rejected, (state, action) => {
        state.updateLoading = false;
        state.error = action.payload as string;
      })
      
      // Partial update
      .addCase(partialUpdateCliente.pending, (state) => {
        state.updateLoading = true;
      })
      .addCase(partialUpdateCliente.fulfilled, (state, action) => {
        state.updateLoading = false;
        if (state.data) {
          state.data = { ...state.data, ...action.payload };
        }
      })
      .addCase(partialUpdateCliente.rejected, (state, action) => {
        state.updateLoading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearClienteData, clearClienteError, updateLocalClienteData } = clienteSlice.actions;
export default clienteSlice.reducer;