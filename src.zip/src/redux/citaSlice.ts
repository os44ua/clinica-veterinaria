import { createSlice, createAsyncThunk, type PayloadAction } from '@reduxjs/toolkit';
import { getDatabase, ref, get, set, push, update } from 'firebase/database';
import logger from '../services/logging';

export interface CitaData {
  id?: string;
  clienteUid: string;
  clienteEmail: string;
  mascotaId: string;
  mascotaNombre: string;
  veterinarioUid?: string;
  veterinarioNombre?: string;
  fecha: string;
  hora: string;
  motivo: string;
  estado: 'pendiente' | 'confirmada' | 'rechazada' | 'completada' | 'cancelada';
  observaciones?: string;
  prioridad: 'normal' | 'urgente' | 'alta';
  creadaEn: string;
  actualizadaEn?: string;
}

interface CitaState {
  citas: CitaData[];
  loading: boolean;
  error: string | null;
  addLoading: boolean;
  updateLoading: boolean;
  deleteLoading: boolean;
  filtros: {
    estado?: string;
    fecha?: string;
    veterinario?: string;
  };
}

const initialState: CitaState = {
  citas: [],
  loading: false,
  error: null,
  addLoading: false,
  updateLoading: false,
  deleteLoading: false,
  filtros: {},
};

// Async thunks
export const fetchCitasCliente = createAsyncThunk(
  'cita/fetchCitasCliente',
  async (clienteUid: string, { rejectWithValue }) => {
    try {
      logger.info(`Fetching citas for cliente UID: ${clienteUid}`);
      const db = getDatabase();
      const citasRef = ref(db, `citas`);
      const snapshot = await get(citasRef);
      
      if (snapshot.exists()) {
        const data = snapshot.val();
        const citas = Object.keys(data)
          .filter(id => data[id].clienteUid === clienteUid)
          .map(id => ({
            id,
            ...data[id]
          })) as CitaData[];
        
        logger.info(`Found ${citas.length} citas for cliente`);
        return citas;
      } else {
        logger.info('No citas found');
        return [];
      }
    } catch (error: any) {
      logger.error(`Error fetching citas:`, error);
      return rejectWithValue(error.message);
    }
  }
);

export const addCita = createAsyncThunk(
  'cita/addCita',
  async (citaData: Omit<CitaData, 'id' | 'creadaEn'>, { rejectWithValue }) => {
    try {
      logger.info(`Adding new cita for mascota: ${citaData.mascotaNombre}`);
      const db = getDatabase();
      const citasRef = ref(db, `citas`);
      
      const citaCompleta = {
        ...citaData,
        creadaEn: new Date().toISOString(),
        estado: 'pendiente' as const
      };
      
      const newCitaRef = push(citasRef);
      await set(newCitaRef, citaCompleta);
      
      const newCita: CitaData = {
        id: newCitaRef.key!,
        ...citaCompleta
      };
      
      logger.info(`Cita added successfully with ID: ${newCita.id}`);
      return newCita;
    } catch (error: any) {
      logger.error(`Error adding cita:`, error);
      return rejectWithValue(error.message);
    }
  }
);

export const updateEstadoCita = createAsyncThunk(
  'cita/updateEstado',
  async ({ id, estado, observaciones }: { id: string; estado: CitaData['estado']; observaciones?: string }, { rejectWithValue }) => {
    try {
      logger.info(`Updating cita estado: ${id} to ${estado}`);
      const db = getDatabase();
      const citaRef = ref(db, `citas/${id}`);
      
      const updates: any = {
        estado,
        actualizadaEn: new Date().toISOString()
      };
      
      if (observaciones) {
        updates.observaciones = observaciones;
      }
      
      await update(citaRef, updates);
      
      logger.info('Cita estado updated successfully');
      return { id, estado, observaciones, actualizadaEn: updates.actualizadaEn };
    } catch (error: any) {
      logger.error(`Error updating cita estado:`, error);
      return rejectWithValue(error.message);
    }
  }
);

const citaSlice = createSlice({
  name: 'cita',
  initialState,
  reducers: {
    clearCitas: (state) => {
      logger.info('Clearing citas data');
      state.citas = [];
      state.error = null;
    },
    clearCitaError: (state) => {
      state.error = null;
    },
    setFiltros: (state, action: PayloadAction<Partial<CitaState['filtros']>>) => {
      state.filtros = { ...state.filtros, ...action.payload };
    },
    clearFiltros: (state) => {
      state.filtros = {};
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch citas cliente
      .addCase(fetchCitasCliente.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchCitasCliente.fulfilled, (state, action) => {
        state.loading = false;
        state.citas = action.payload;
        state.error = null;
      })
      .addCase(fetchCitasCliente.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      
      // Add cita
      .addCase(addCita.pending, (state) => {
        state.addLoading = true;
        state.error = null;
      })
      .addCase(addCita.fulfilled, (state, action) => {
        state.addLoading = false;
        state.citas.push(action.payload);
        state.error = null;
      })
      .addCase(addCita.rejected, (state, action) => {
        state.addLoading = false;
        state.error = action.payload as string;
      })
      
      // Update estado
      .addCase(updateEstadoCita.fulfilled, (state, action) => {
        const { id, estado, observaciones, actualizadaEn } = action.payload;
        const index = state.citas.findIndex(c => c.id === id);
        if (index !== -1) {
          state.citas[index] = {
            ...state.citas[index],
            estado,
            observaciones: observaciones || state.citas[index].observaciones,
            actualizadaEn
          };
        }
      });
  },
});

export const { 
  clearCitas, 
  clearCitaError, 
  setFiltros, 
  clearFiltros 
} = citaSlice.actions;

export default citaSlice.reducer;