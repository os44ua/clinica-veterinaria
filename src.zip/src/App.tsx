// App.tsx
import { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';

// Redux
import { ReduxProvider } from './providers/ReduxProvider';

// Componentes de autenticación
import { AuthProvider } from './contexts/AuthContext';
import logger from './services/logging';
import Navbar from './components/Navbar';
import ErrorBoundary from './components/ErrorBoundary';

// Páginas
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import PerfilCliente from './pages/PerfilCliente';
import AdminVets from './pages/AdminVets';

// Maršrutas
import ProtectedRoute from './routes/ProtectedRoute';
import AdminRoute from './routes/AdminRoute';
import PerfilVeterinario from './pages/PerfilVeterinario';

function AppContent() {
  useEffect(() => {
    logger.info("🚀 Aplicación con Redux y autenticación iniciada");
    return () => {
      logger.info("🔚 Aplicación finalizada");
    };
  }, []);

  const errorFallback = (
    <div className="errorFallback p-8 text-center">
      <h2 className="text-2xl font-bold text-red-600 mb-4">¡Algo salió mal!</h2>
      <p className="text-gray-600 mb-4">
        Ha ocurrido un error inesperado. Por favor, intenta recargar la página.
      </p>
      <button 
        onClick={() => window.location.reload()}
        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
      >
        🔄 Recargar página
      </button>
    </div>
  );

  return (
    <AuthProvider>
      <Router>
        <ErrorBoundary fallback={errorFallback}>
          <Navbar />
          <div className="main-content min-h-screen bg-gray-50">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />

              {/* Rutas protegidas para clientes */}
              <Route path="/perfilcliente" element={
                <ProtectedRoute>
                  <PerfilCliente />
                </ProtectedRoute>
              } />

              {/* Rutas protegidas para veterinarios */}
              <Route path="/perfilveterinario" element={
                <ProtectedRoute>
                  <PerfilVeterinario />
                </ProtectedRoute>
              } />

              {/* Rutas protegidas para administradores */}
              <Route path="/adminvets" element={
                <AdminRoute>
                  <AdminVets />
                </AdminRoute>
              } />
              
              {/* Ruta catch-all */}
              <Route path="*" element={<Home />} />
            </Routes>
          </div>
        </ErrorBoundary>
      </Router>
    </AuthProvider>
  );
}

function App() {
  return (
    <ReduxProvider>
      <AppContent />
    </ReduxProvider>
  );
}

export default App;


