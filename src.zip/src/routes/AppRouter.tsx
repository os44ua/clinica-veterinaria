import { BrowserRouter, Routes, Route } from "react-router-dom";
import Inicio from "../pages/Home";
import Login from "../pages/Login";
import PerfilCliente from "../pages/PerfilCliente";
import PerfilVeterinario from "../pages/PerfilVeterinario";
import AdminVets from "../pages/AdminVets";
import Register from "../pages/Register";




export default function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Inicio />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/perfilcliente" element={<PerfilCliente />} />
        <Route path="/perfilveterinario" element={<PerfilVeterinario />} />
        <Route path="/admin-vets" element={<AdminVets />} />
      </Routes>
    </BrowserRouter>
  );
}
